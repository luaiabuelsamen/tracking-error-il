import cv2

cap = cv2.VideoCapture(0)
ret, frame = cap.read()
if ret:
    cv2.imwrite("camera_frame.jpg", frame)
    print("Saved camera_frame.jpg")
else:
    print("Failed to grab frame")
cap.release()
