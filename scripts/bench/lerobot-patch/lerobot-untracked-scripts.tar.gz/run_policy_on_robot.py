import cv2
import numpy as np
import time
import torch
from lerobot.robots import make_robot_from_config
from lerobot.policies.diffusion.modeling_diffusion import DiffusionPolicy
from lerobot.robots.so101_follower.config_so101_follower import SO101FollowerConfig
from lerobot.cameras.opencv.configuration_opencv import OpenCVCameraConfig

robot_config = SO101FollowerConfig(
    port='/dev/ttyACM0',
    id='my_awesome_follower_arm',
    cameras={
        'cam0': OpenCVCameraConfig(
            index_or_path='/dev/video0',
            width=640,
            height=480,
            fps=30
        )
    }
)

POLICY_PATH = 'outputs/train/2025-08-29/22-34-09_diffusion/checkpoints/last/pretrained_model'
DEVICE = 'cuda' if torch.cuda.is_available() else 'cpu'

def preprocess_image(image):
    """Preprocess camera image for the diffusion policy."""
    # Ensure RGB and resize
    if len(image.shape) == 3 and image.shape[2] > 3:
        image = image[:, :, :3]
    elif len(image.shape) == 2:
        image = cv2.cvtColor(image, cv2.COLOR_GRAY2RGB)
    
    image = cv2.resize(image, (84, 84))
    image = image.astype(np.float32) / 255.0
    image = image.transpose(2, 0, 1)  # HWC to CHW
    
    return image

def main():
    # Connect to robot
    robot = make_robot_from_config(robot_config)
    robot.connect()

    # Load policy
    policy = DiffusionPolicy.from_pretrained(POLICY_PATH)
    policy.to(DEVICE)
    policy.eval()
    policy.reset()
    
    print('Running policy on robot. Press Ctrl+C to stop.')
    
    try:
        while True:
            # Get observation
            raw_obs = robot.get_observation()
            
            # Process camera
            cam_img = raw_obs.get('cam0')
            if cam_img is None:
                continue
            
            # Save original image (optional - remove if not needed)
            cv2.imwrite('current_camera_view.jpg', cam_img)
                
            processed_img = preprocess_image(cam_img)
            
            # Save processed image for debugging
            processed_display = (processed_img.transpose(1, 2, 0) * 255).astype(np.uint8)
            cv2.imwrite('processed_camera_view.jpg', processed_display)
            
            cam_tensor = torch.from_numpy(processed_img).unsqueeze(0).to(DEVICE)
            
            # Get robot state
            state_keys = [k for k in raw_obs.keys() if k != 'cam0']
            state_values = [raw_obs[key] for key in sorted(state_keys)]
            state_tensor = torch.tensor(state_values, dtype=torch.float32, device=DEVICE).unsqueeze(0)
            
            # Create observation
            obs = {
                'observation.state': state_tensor,
                'observation.images.cam0': cam_tensor
            }
            
            # Get action
            with torch.no_grad():
                action = policy.select_action(obs)
            
            # Convert to robot format
            action = action.cpu().numpy().squeeze()
            action_keys = sorted([k for k in robot.action_features])
            action_dict = {key: float(action[i]) for i, key in enumerate(action_keys)}
            
            # Send action
            robot.send_action(action_dict)
            time.sleep(1.0 / 30)
            
    except KeyboardInterrupt:
        print('Stopping.')
    finally:
        robot.disconnect()

if __name__ == '__main__':
    main()