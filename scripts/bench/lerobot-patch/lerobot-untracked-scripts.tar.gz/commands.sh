# calibrate
# python src/lerobot/scripts/lerobot_calibrate.py --teleop.type=so101_follower --robot.port=/dev/ttyACM0
# python src/lerobot/scripts/lerobot_calibrate.py --teleop.type=so101_leader --robot.port=/dev/ttyACM1

#teleop
# lerobot-teleoperate --robot.type=so101_follower --robot.port=/dev/ttyACM0 --robot.id=my_awesome_follower_arm --teleop.type=so101_leader --teleop.port=/dev/ttyACM1 --teleop.id=my_awesome_leader_arm

#record demos
# Clean up first
rm -rf screwdriver_v2/
rm -rf /tmp/screwdriver_v2
rm /tmp/*.ffconcat 2>/dev/null

# Create symbolic link (this is the key fix)
ln -s /home/jetson3/clean_env/lerobot/screwdriver_v2 /tmp/screwdriver_v2

# Verify the symlink
ls -la /tmp/ | grep screwdriver_v2

# Now record (WITHOUT video_backend argument)
cd /home/jetson3/clean_env/lerobot && source ../venv/bin/activate && \
python -m lerobot.scripts.lerobot_record \
  --robot.type=so101_follower \
  --robot.port=/dev/ttyACM0 \
  --robot.cameras='{"front": {"type": "opencv", "index_or_path": "/dev/video0", "width": 640, "height": 480, "fps": 30}}' \
  --teleop.type=so101_leader \
  --teleop.port=/dev/ttyACM1 \
  --dataset.fps=30 \
  --dataset.repo_id=luaia/screwdriver_v2 \
  --dataset.root=screwdriver_v2 \
  --dataset.single_task="Pick up the screw" \
  --dataset.num_episodes=15 \
  --dataset.episode_time_s=20 \
  --dataset.reset_time_s=5 \
  --dataset.push_to_hub=false \
  --display_data=false
  #--resume=true

#train dp
python -m lerobot.scripts.lerobot_train \
  --policy.type=diffusion \
  --dataset.repo_id=lerobot/screwdriver_v2_local \
  --dataset.root=screwdriver_v2 \
  --dataset.video_backend=pyav \
  --output_dir=outputs/train/diffusion_screwdriver_v2 \
  --policy.repo_id=luaia/diffusion_screwdriver_v2 \
  --steps=10000 \
  --batch_size=8 \
  --save_freq=1000 \
  --num_workers=4 \
  --policy.device=cuda \
  --wandb.enable=false
#eval
python -m lerobot.scripts.lerobot_record \
  --robot.type=so101_follower \
  --robot.port=/dev/ttyACM0 \
  --robot.cameras='{"front": {"type": "opencv", "index_or_path": "/dev/video0", "width": 640, "height": 480, "fps": 30}}' \
  --policy.path=outputs/train/diffusion_screwdriver_v2/checkpoints/010000/pretrained_model \
  --policy.num_inference_steps=4 \
  --dataset.repo_id=luaia/eval_diffusion_v2 \
  --dataset.root=eval_diffusion_v2 \
  --dataset.single_task="Pick up the screw" \
  --dataset.num_episodes=1 \
  --dataset.episode_time_s=20 \
  --dataset.push_to_hub=false \
  --display_data=false

#train act
python -m lerobot.scripts.lerobot_train \
  --policy.type=act \
  --dataset.repo_id=lerobot/screwdriver_v2_local \
  --dataset.root=screwdriver_v2 \
  --dataset.video_backend=pyav \
  --output_dir=outputs/train/act_screwdriver_v2 \
  --policy.repo_id=luaia/act_screwdriver_v2 \
  --steps=10000 \
  --batch_size=8 \
  --save_freq=1000 \
  --num_workers=4 \
  --policy.device=cuda \
  --wandb.enable=false
#eval 
python -m lerobot.scripts.lerobot_record \
  --robot.type=so101_follower \
  --robot.port=/dev/ttyACM0 \
  --robot.cameras='{"front": {"type": "opencv", "index_or_path": "/dev/video0", "width": 640, "height": 480, "fps": 30}}' \
  --policy.path="outputs/train/act_screwdriver_v2/checkpoints/010000/pretrained_model" \
  --dataset.repo_id=luaia/eval_act_v2 \
  --dataset.root=eval_act_v2 \
  --dataset.single_task="Pick up the screw" \
  --dataset.num_episodes=1\
  --dataset.episode_time_s=20 \
  --dataset.push_to_hub=false \
  --display_data=false