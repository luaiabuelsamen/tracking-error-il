#!/usr/bin/env python3

"""
Fine-tune PI0 on your SO101 screwdriver pickup dataset
"""

import torch
import torch.optim as optim
from torch.utils.data import DataLoader
from transformers import AutoTokenizer
import numpy as np
import json
from pathlib import Path
import argparse
from tqdm import tqdm
import wandb

from lerobot.policies.pi0.modeling_pi0 import PI0Policy
from lerobot.common.datasets.lerobot_dataset import LeRobotDataset
from lerobot.utils.constants import OBS_LANGUAGE_TOKENS, OBS_LANGUAGE_ATTENTION_MASK

def setup_training_args():
    parser = argparse.ArgumentParser()
    parser.add_argument("--dataset_path", type=str, default="my_so101_dataset", 
                        help="Path to your dataset")
    parser.add_argument("--output_dir", type=str, default="./pi0_finetuned", 
                        help="Directory to save the fine-tuned model")
    parser.add_argument("--batch_size", type=int, default=1, 
                        help="Batch size (start small for Jetson)")
    parser.add_argument("--learning_rate", type=float, default=1e-5, 
                        help="Learning rate for fine-tuning")
    parser.add_argument("--num_epochs", type=int, default=50, 
                        help="Number of training epochs")
    parser.add_argument("--task_description", type=str, default="pick up the screwdriver", 
                        help="Task description for language conditioning")
    parser.add_argument("--pretrained_model", type=str, default="lerobot/pi0", 
                        help="Pretrained PI0 model to fine-tune")
    parser.add_argument("--device", type=str, default="cuda:0", 
                        help="Device to use for training")
    parser.add_argument("--save_every", type=int, default=10, 
                        help="Save checkpoint every N epochs")
    parser.add_argument("--use_wandb", action="store_true", 
                        help="Use Weights & Biases for logging")
    
    return parser.parse_args()

class SO101PI0Dataset:
    """Custom dataset for SO101 data compatible with PI0"""
    
    def __init__(self, dataset_path, tokenizer, task_description, device):
        self.dataset_path = Path(dataset_path)
        self.tokenizer = tokenizer
        self.task_description = task_description
        self.device = device
        
        # Load the LeRobot dataset
        self.dataset = LeRobotDataset(str(dataset_path))
        
        # Tokenize task description once
        tokenized = self.tokenizer(
            [task_description], 
            max_length=512, 
            truncation=True, 
            padding="max_length", 
            return_tensors="pt"
        )
        self.lang_tokens = tokenized["input_ids"].to(device)
        self.lang_mask = tokenized["attention_mask"].to(dtype=torch.bool, device=device)
        
        print(f"Dataset loaded: {len(self.dataset)} samples")
        print(f"Task: {task_description}")
        
    def __len__(self):
        return len(self.dataset)
    
    def __getitem__(self, idx):
        sample = self.dataset[idx]
        
        # Get image - assume it's stored as 'observation.images.cam0'
        image_key = 'observation.images.cam0'
        if image_key not in sample:
            # Try alternative keys
            for key in sample.keys():
                if 'image' in key.lower() or 'cam' in key.lower():
                    image_key = key
                    break
        
        # Process image
        image = sample[image_key]  # Should be [H, W, 3]
        if isinstance(image, np.ndarray):
            # Convert to tensor and normalize
            image = torch.from_numpy(image).float() / 255.0
            # Resize to 224x224 and convert to CHW format
            image = torch.nn.functional.interpolate(
                image.permute(2, 0, 1).unsqueeze(0), 
                size=(224, 224), 
                mode='bilinear'
            ).squeeze(0)
        
        # Get robot state
        state = sample['observation.state']
        if isinstance(state, np.ndarray):
            state = torch.from_numpy(state).float()
        
        # Get action
        action = sample['action']
        if isinstance(action, np.ndarray):
            action = torch.from_numpy(action).float()
        
        # Create observation dict for PI0
        obs = {
            'observation.state': state.unsqueeze(0).to(self.device),
            'observation.images.camera0': image.unsqueeze(0).to(self.device),
            OBS_LANGUAGE_TOKENS: self.lang_tokens,
            OBS_LANGUAGE_ATTENTION_MASK: self.lang_mask,
        }
        
        return obs, action.to(self.device)

def train_epoch(model, dataloader, optimizer, device, epoch):
    model.train()
    total_loss = 0
    num_batches = len(dataloader)
    
    progress_bar = tqdm(dataloader, desc=f"Epoch {epoch}")
    
    for batch_idx, (obs, actions) in enumerate(progress_bar):
        optimizer.zero_grad()
        
        try:
            # Forward pass - PI0 expects batch dimension
            predicted_actions = model.select_action(obs)
            
            # Compute loss (MSE between predicted and actual actions)
            if predicted_actions.dim() == 1:
                predicted_actions = predicted_actions.unsqueeze(0)
            if actions.dim() == 1:
                actions = actions.unsqueeze(0)
                
            loss = torch.nn.functional.mse_loss(predicted_actions, actions)
            
            # Backward pass
            loss.backward()
            
            # Gradient clipping
            torch.nn.utils.clip_grad_norm_(model.parameters(), max_norm=1.0)
            
            optimizer.step()
            
            total_loss += loss.item()
            avg_loss = total_loss / (batch_idx + 1)
            
            progress_bar.set_postfix({
                'loss': f'{loss.item():.6f}', 
                'avg_loss': f'{avg_loss:.6f}'
            })
            
        except Exception as e:
            print(f"Error in batch {batch_idx}: {e}")
            continue
    
    return total_loss / num_batches

def main():
    args = setup_training_args()
    
    # Setup device
    device = torch.device(args.device if torch.cuda.is_available() else "cpu")
    print(f"Using device: {device}")
    
    # Initialize W&B if requested
    if args.use_wandb:
        wandb.init(
            project="pi0-so101-finetune",
            config=vars(args),
            name=f"pi0_screwdriver_{args.learning_rate}"
        )
    
    # Load tokenizer
    print("Loading tokenizer...")
    tokenizer = AutoTokenizer.from_pretrained("google/paligemma-3b-pt-224")
    
    # Load pretrained PI0 model
    print(f"Loading pretrained PI0 model: {args.pretrained_model}")
    model = PI0Policy.from_pretrained(args.pretrained_model)
    model.to(device)
    
    print(f"Model loaded on {next(model.parameters()).device}")
    print(f"Model parameters: {sum(p.numel() for p in model.parameters()):,}")
    print(f"Trainable parameters: {sum(p.numel() for p in model.parameters() if p.requires_grad):,}")
    
    # Create dataset and dataloader
    print("Loading dataset...")
    dataset = SO101PI0Dataset(
        args.dataset_path, 
        tokenizer, 
        args.task_description, 
        device
    )
    
    dataloader = DataLoader(
        dataset, 
        batch_size=args.batch_size, 
        shuffle=True,
        num_workers=0  # Set to 0 for Jetson to avoid multiprocessing issues
    )
    
    # Setup optimizer
    optimizer = optim.AdamW(model.parameters(), lr=args.learning_rate, weight_decay=1e-4)
    
    # Create output directory
    output_dir = Path(args.output_dir)
    output_dir.mkdir(exist_ok=True)
    
    # Training loop
    print(f"Starting training for {args.num_epochs} epochs...")
    best_loss = float('inf')
    
    for epoch in range(args.num_epochs):
        epoch_loss = train_epoch(model, dataloader, optimizer, device, epoch + 1)
        
        print(f"Epoch {epoch + 1}/{args.num_epochs}, Loss: {epoch_loss:.6f}")
        
        # Log to W&B
        if args.use_wandb:
            wandb.log({"epoch": epoch + 1, "loss": epoch_loss})
        
        # Save checkpoint
        if (epoch + 1) % args.save_every == 0 or epoch_loss < best_loss:
            if epoch_loss < best_loss:
                best_loss = epoch_loss
                checkpoint_name = "best_model.pt"
                print(f"New best model! Loss: {epoch_loss:.6f}")
            else:
                checkpoint_name = f"checkpoint_epoch_{epoch + 1}.pt"
            
            checkpoint_path = output_dir / checkpoint_name
            torch.save({
                'epoch': epoch + 1,
                'model_state_dict': model.state_dict(),
                'optimizer_state_dict': optimizer.state_dict(),
                'loss': epoch_loss,
                'args': vars(args)
            }, checkpoint_path)
            print(f"Saved: {checkpoint_path}")
    
    # Save final model
    final_model_path = output_dir / "final_model.pt"
    torch.save({
        'model_state_dict': model.state_dict(),
        'args': vars(args)
    }, final_model_path)
    print(f"Training complete! Final model saved: {final_model_path}")
    
    # Save the model in HuggingFace format too
    hf_model_path = output_dir / "hf_model"
    model.save_pretrained(hf_model_path)
    tokenizer.save_pretrained(hf_model_path)
    print(f"HuggingFace format saved: {hf_model_path}")

if __name__ == "__main__":
    main()
