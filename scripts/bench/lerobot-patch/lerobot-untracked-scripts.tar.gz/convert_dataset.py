#!/usr/bin/env python3

import pandas as pd
import jsonlines

# Convert tasks.jsonl to tasks.parquet
with jsonlines.open('/home/jetson3/clean_env/lerobot/my_so101_dataset/meta/tasks.jsonl', 'r') as reader:
    tasks_data = list(reader)

tasks_df = pd.DataFrame(tasks_data)
tasks_df.to_parquet('/home/jetson3/clean_env/lerobot/my_so101_dataset/meta/tasks.parquet', index=False)

print("Converted tasks.jsonl to tasks.parquet")

# Convert episodes.jsonl to episodes.parquet  
with jsonlines.open('/home/jetson3/clean_env/lerobot/my_so101_dataset/meta/episodes.jsonl', 'r') as reader:
    episodes_data = list(reader)

episodes_df = pd.DataFrame(episodes_data)
episodes_df.to_parquet('/home/jetson3/clean_env/lerobot/my_so101_dataset/meta/episodes.parquet', index=False)

print("Converted episodes.jsonl to episodes.parquet")

print("Dataset format conversion completed!")
