"""Probe Present_Current / Present_Load on the SO-101 follower.

Opens the Feetech bus directly (no lerobot Robot wrapper) and prints raw,
two's-complement-decoded, and sign-magnitude-decoded interpretations of
Present_Current alongside Present_Load (already decoded by the bus) so we
can identify the correct encoding empirically.

Usage:
    python probe_currents.py [--port /dev/ttyACM0] [--hz 20]

Move each joint by hand (or under load) in both directions and watch which
column flips sign symmetrically. Ctrl+C to exit.
"""

import argparse
import os
import signal
import sys
import time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "src"))

from lerobot.motors import Motor, MotorNormMode
from lerobot.motors.feetech import FeetechMotorsBus

MOTORS = {
    "shoulder_pan":  (1, "sts3215", MotorNormMode.RANGE_M100_100),
    "shoulder_lift": (2, "sts3215", MotorNormMode.RANGE_M100_100),
    "elbow_flex":    (3, "sts3215", MotorNormMode.RANGE_M100_100),
    "wrist_flex":    (4, "sts3215", MotorNormMode.RANGE_M100_100),
    "wrist_roll":    (5, "sts3215", MotorNormMode.RANGE_M100_100),
    "gripper":       (6, "sts3215", MotorNormMode.RANGE_0_100),
}


def twos_complement_16(u: int) -> int:
    return u - 65536 if u >= 32768 else u


def sign_magnitude_16(u: int) -> int:
    sign = -1 if (u & 0x8000) else 1
    return sign * (u & 0x7FFF)


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--port", default="/dev/ttyACM0")
    p.add_argument("--hz", type=float, default=20.0)
    p.add_argument(
        "--enable-torque",
        action="store_true",
        help="Energize the motors so they hold position. Required to see nonzero current/load. Torque is disabled again on exit.",
    )
    args = p.parse_args()

    bus = FeetechMotorsBus(
        port=args.port,
        motors={name: Motor(mid, model, norm) for name, (mid, model, norm) in MOTORS.items()},
        calibration=None,
    )

    print(f"Connecting to {args.port} ...")
    bus.connect()
    print("Connected.")

    if args.enable_torque:
        print(
            "\n[!] About to ENABLE TORQUE — the arm will stiffen at its current pose.\n"
            "    Make sure the arm is clear of obstacles and you can release it manually.\n"
            "    Press ENTER to energize, Ctrl+C to abort."
        )
        try:
            input()
        except (EOFError, KeyboardInterrupt):
            print("Aborted.")
            bus.disconnect(disable_torque=True)
            return 0
        bus.enable_torque()
        # Verify torque actually engaged on every motor
        te = bus.sync_read("Torque_Enable", normalize=False)
        print(f"Torque_Enable readback: {dict(te)}")
        if not all(int(v) == 1 for v in te.values()):
            print("[!] WARNING: not all motors report Torque_Enable=1")
        print("\n>>> TORQUE IS NOW ON — START PUSHING JOINTS <<<\n")

    print("Reading at {:.0f} Hz. Ctrl+C to stop.\n".format(args.hz))

    stopped = {"flag": False}

    def _stop(*_):
        stopped["flag"] = True

    signal.signal(signal.SIGINT, _stop)

    names = list(MOTORS.keys())
    header_fmt = "{:>14s} | {:>7s} | {:>7s} {:>7s} {:>7s} | {:>7s}"
    row_fmt    = "{:>14s} | {:>7.1f} | {:>7d} {:>7d} {:>7d} | {:>7d}"
    period = 1.0 / args.hz

    try:
        while not stopped["flag"]:
            t0 = time.perf_counter()
            pos     = bus.sync_read("Present_Position", normalize=False)
            cur_raw = bus.sync_read("Present_Current", normalize=False)
            load    = bus.sync_read("Present_Load",    normalize=False)
            dt_ms   = (time.perf_counter() - t0) * 1e3

            print(f"--- t={time.strftime('%H:%M:%S')}  read_dt={dt_ms:.1f}ms ---")
            print(header_fmt.format("motor", "pos", "I_raw", "I_two", "I_sm", "Load"))
            for n in names:
                u = int(cur_raw[n]) & 0xFFFF
                print(row_fmt.format(
                    n,
                    float(pos[n]),
                    u,
                    twos_complement_16(u),
                    sign_magnitude_16(u),
                    int(load[n]),
                ))
            print()

            elapsed = time.perf_counter() - t0
            if elapsed < period:
                time.sleep(period - elapsed)
    finally:
        print("\nDisconnecting (disable_torque={}) ...".format(args.enable_torque))
        bus.disconnect(disable_torque=args.enable_torque)
    return 0


if __name__ == "__main__":
    sys.exit(main())
