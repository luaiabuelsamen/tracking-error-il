import cv2
import numpy as np
import time
import torch
from lerobot.robots import make_robot_from_config
from lerobot.policies.pi0.modeling_pi0 import PI0Policy
from lerobot.robots.so101_follower.config_so101_follower import SO101FollowerConfig
from lerobot.cameras.opencv.configuration_opencv import OpenCVCameraConfig
from transformers import AutoTokenizer
from lerobot.utils.constants import OBS_LANGUAGE_TOKENS, OBS_LANGUAGE_ATTENTION_MASK
import signal

robot_config = SO101FollowerConfig(
    port='/dev/ttyACM0',
    id='my_awesome_follower_arm',
    cameras={
        'front': OpenCVCameraConfig(
            index_or_path='/dev/video0',
            width=640,
            height=480,
            fps=30
        )
    }
)

# Use the pretrained PI0 model from HuggingFace
POLICY_PATH = 'lerobot/pi0'
DEVICE = 'cuda:0'  # Use GPU for faster inference
TASK_INSTRUCTION = "Pick up the screw driver"  # You can change this instruction

def preprocess_image(image):
    """Preprocess camera image for the PI0 policy."""
    # Ensure RGB
    if len(image.shape) == 3 and image.shape[2] > 3:
        image = image[:, :, :3]
    elif len(image.shape) == 2:
        image = cv2.cvtColor(image, cv2.COLOR_GRAY2RGB)
    
    # Convert BGR to RGB (OpenCV uses BGR by default)
    image = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    
    # PI0 expects (224, 224) images
    image = cv2.resize(image, (224, 224))
    image = image.astype(np.float32) / 255.0
    image = image.transpose(2, 0, 1)  # HWC to CHW
    
    return image

def main():
    # Connect to robot
    robot = make_robot_from_config(robot_config)
    robot.connect()
    
    print(f"Robot connected. Available observation features: {robot.observation_features}")
    print(f"Robot action features: {robot.action_features}")

    # Load PI0 policy from HuggingFace
    print("Loading PI0 policy...")
    policy = PI0Policy.from_pretrained(POLICY_PATH)
    policy.to(DEVICE)
    policy.eval()
    
    # Verify GPU usage
    print(f"✅ Policy device: {next(policy.parameters()).device}")
    print(f"✅ CUDA available: {torch.cuda.is_available()}")
    if torch.cuda.is_available():
        print(f"✅ GPU: {torch.cuda.get_device_name()}")
        print(f"✅ GPU Memory: {torch.cuda.get_device_properties(0).total_memory / 1e9:.1f} GB")
    
    # Initialize tokenizer (PI0 uses PaliGemma tokenizer)
    tokenizer = AutoTokenizer.from_pretrained("google/paligemma-3b-pt-224")
    
    # Tokenize task instruction once
    print(f"Tokenizing task: {TASK_INSTRUCTION}")
    tokenized = tokenizer([TASK_INSTRUCTION], max_length=512, truncation=True, padding="max_length", return_tensors="pt")
    lang_tokens = tokenized["input_ids"].to(DEVICE)
    lang_mask = tokenized["attention_mask"].to(dtype=torch.bool, device=DEVICE)
    
    print(f'Running PI0 policy on robot with task: "{TASK_INSTRUCTION}"')
    print('Press Ctrl+C to stop.')
    
    try:
        while True:
            # Get observation
            raw_obs = robot.get_observation()
            
            # Process camera
            cam_img = raw_obs.get('front')
            if cam_img is None:
                print("No camera image received")
                continue
            
            # Save original image (for debugging)
            cv2.imwrite('current_camera_view.jpg', cam_img)
                
            processed_img = preprocess_image(cam_img)
            
            # Save processed image for debugging
            processed_display = (processed_img.transpose(1, 2, 0) * 255).astype(np.uint8)
            processed_display = cv2.cvtColor(processed_display, cv2.COLOR_RGB2BGR)  # Convert back to BGR for saving
            cv2.imwrite('processed_camera_view.jpg', processed_display)
            
            cam_tensor = torch.from_numpy(processed_img).unsqueeze(0).to(DEVICE)
            
            # Get robot state - use all non-camera observations
            state_keys = [k for k in raw_obs.keys() if k != 'front']
            if state_keys:
                state_values = [raw_obs[key] for key in sorted(state_keys)]
                # Flatten in case we have nested arrays
                flattened_values = []
                for val in state_values:
                    if isinstance(val, (list, np.ndarray)):
                        if isinstance(val, np.ndarray):
                            flattened_values.extend(val.flatten())
                        else:
                            flattened_values.extend(val)
                    else:
                        flattened_values.append(val)
                state_tensor = torch.tensor(flattened_values, dtype=torch.float32, device=DEVICE).unsqueeze(0)
            else:
                # Create a dummy state if no state available
                state_tensor = torch.zeros((1, 6), dtype=torch.float32, device=DEVICE)
            
            # Create observation for PI0 - it expects specific camera names and language tokens
            obs = {
                'observation.state': state_tensor,
                'observation.images.camera0': cam_tensor,  # PI0 expects camera0, camera1, camera2
                OBS_LANGUAGE_TOKENS: lang_tokens,
                OBS_LANGUAGE_ATTENTION_MASK: lang_mask,
            }
            
            # PI0 also needs the task instruction
            obs['task'] = TASK_INSTRUCTION
            
            print(f"State shape: {state_tensor.shape}, Image shape: {cam_tensor.shape}")
            
            # Get action from PI0
            with torch.no_grad():
                action = policy.select_action(obs)
            
            # Convert to robot format
            action = action.cpu().numpy().squeeze()
            print(f"Action shape: {action.shape}, Action: {action}")
            
            # Map action to robot action features
            action_keys = sorted([k for k in robot.action_features])
            min_len = min(len(action), len(action_keys))
            action_dict = {action_keys[i]: float(action[i]) for i in range(min_len)}
            
            print(f"Sending action: {action_dict}")
            
            # Send action
            robot.send_action(action_dict)
            time.sleep(1.0 / 30)  # 30 Hz control loop
            
    except KeyboardInterrupt:
        print('Stopping.')
    except Exception as e:
        print(f'Error: {e}')
        import traceback
        traceback.print_exc()
    finally:
        robot.disconnect()

if __name__ == '__main__':
    main()
