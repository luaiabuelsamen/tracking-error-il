"""Active probe: force motors to fight against you so current must be nonzero.

Picks shoulder_lift only (least dangerous joint to play with). Reads its
current position, then commands a goal position +/- a small offset every 3
seconds. Prints Position, Velocity, Voltage, Current, Load each cycle.

This isolates two questions:
  1. Does the firmware actually populate Present_Current / Present_Load?
     (If Voltage / Velocity are nonzero but Current / Load stay at 0, the
     firmware doesn't report them — we'll need a workaround.)
  2. Which decode (two's-complement vs sign-magnitude) flips correctly when
     the goal alternates above/below the current pose.
"""

import argparse
import os
import signal
import sys
import time

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "src"))

from lerobot.motors import Motor, MotorNormMode
from lerobot.motors.feetech import FeetechMotorsBus

MOTORS = {
    "shoulder_pan":  (1, "sts3215", MotorNormMode.RANGE_M100_100),
    "shoulder_lift": (2, "sts3215", MotorNormMode.RANGE_M100_100),
    "elbow_flex":    (3, "sts3215", MotorNormMode.RANGE_M100_100),
    "wrist_flex":    (4, "sts3215", MotorNormMode.RANGE_M100_100),
    "wrist_roll":    (5, "sts3215", MotorNormMode.RANGE_M100_100),
    "gripper":       (6, "sts3215", MotorNormMode.RANGE_0_100),
}


def twos(u: int) -> int:
    return u - 65536 if u >= 32768 else u


def smag(u: int) -> int:
    return (-1 if (u & 0x8000) else 1) * (u & 0x7FFF)


def main() -> int:
    p = argparse.ArgumentParser()
    p.add_argument("--port", default="/dev/ttyACM0")
    p.add_argument("--motor", default="shoulder_lift")
    p.add_argument("--offset", type=int, default=80,
                   help="Goal position offset in raw counts (4096 per turn). 80 ~= 7 degrees.")
    p.add_argument("--period", type=float, default=3.0,
                   help="Seconds between goal-position flips.")
    p.add_argument("--hz", type=float, default=20.0)
    args = p.parse_args()

    bus = FeetechMotorsBus(
        port=args.port,
        motors={n: Motor(mid, m, norm) for n, (mid, m, norm) in MOTORS.items()},
        calibration=None,
    )
    print(f"Connecting to {args.port} ...")
    bus.connect()
    print("Connected.")

    # Read fresh firmware info to rule out 'firmware too old to report current'
    try:
        fw_major = bus.sync_read("Firmware_Major_Version", normalize=False)
        fw_minor = bus.sync_read("Firmware_Minor_Version", normalize=False)
        print(f"Firmware: { {k: f'{fw_major[k]}.{fw_minor[k]}' for k in fw_major} }")
    except Exception as e:
        print(f"(could not read firmware: {e})")

    # Read starting position for the target joint
    start_pos = int(bus.sync_read("Present_Position", normalize=False)[args.motor])
    print(f"\nTarget motor: {args.motor}  start_pos={start_pos}")
    print(f"Will alternate goal between {start_pos - args.offset} and {start_pos + args.offset} every {args.period}s")
    print("\n[!] About to ENABLE TORQUE and command motion. Clear the arm path.")
    print("    Press ENTER to begin, Ctrl+C to abort.")
    try:
        input()
    except (EOFError, KeyboardInterrupt):
        print("Aborted.")
        bus.disconnect(disable_torque=True)
        return 0

    bus.enable_torque()
    te = bus.sync_read("Torque_Enable", normalize=False)
    print(f"Torque_Enable: {dict(te)}")
    if int(te[args.motor]) != 1:
        print(f"[!] {args.motor} did not enable torque — aborting.")
        bus.disconnect(disable_torque=True)
        return 1

    stop = {"f": False}
    signal.signal(signal.SIGINT, lambda *_: stop.update(f=True))

    period = 1.0 / args.hz
    next_flip = time.perf_counter() + args.period
    goal = start_pos + args.offset
    bus.sync_write("Goal_Position", {args.motor: goal}, normalize=False)
    print(f"\nCommanded {args.motor} -> {goal}\n")

    hdr = "{:>14s} | {:>5s} | {:>5s} | {:>5s} | {:>5s} {:>5s} {:>5s} | {:>5s}"
    row = "{:>14s} | {:>5d} | {:>5d} | {:>5d} | {:>5d} {:>5d} {:>5d} | {:>5d}"

    try:
        while not stop["f"]:
            t0 = time.perf_counter()
            pos = bus.sync_read("Present_Position", normalize=False)
            vel = bus.sync_read("Present_Velocity", normalize=False)
            volt = bus.sync_read("Present_Voltage", normalize=False)
            cur = bus.sync_read("Present_Current", normalize=False)
            load = bus.sync_read("Present_Load", normalize=False)

            now = time.perf_counter()
            if now >= next_flip:
                goal = (start_pos - args.offset) if goal > start_pos else (start_pos + args.offset)
                bus.sync_write("Goal_Position", {args.motor: goal}, normalize=False)
                next_flip = now + args.period
                print(f"\n>>> flipped goal -> {goal} <<<\n")

            print(f"--- t={time.strftime('%H:%M:%S')} goal={goal} ---")
            print(hdr.format("motor", "pos", "vel", "volt", "I_raw", "I_two", "I_sm", "Load"))
            for n in MOTORS:
                u = int(cur[n]) & 0xFFFF
                print(row.format(
                    n,
                    int(pos[n]),
                    int(vel[n]),
                    int(volt[n]),
                    u,
                    twos(u),
                    smag(u),
                    int(load[n]),
                ))
            print()
            elapsed = time.perf_counter() - t0
            if elapsed < period:
                time.sleep(period - elapsed)
    finally:
        try:
            bus.sync_write("Goal_Position", {args.motor: start_pos})
            time.sleep(0.3)
        except Exception:
            pass
        print("\nDisabling torque, disconnecting ...")
        bus.disconnect(disable_torque=True)
    return 0


if __name__ == "__main__":
    sys.exit(main())
